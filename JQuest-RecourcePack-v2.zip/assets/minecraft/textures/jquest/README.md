# JQuest Resource Pack - Red Background Texture

## Instructions to Create the Red Background

1. Open any image editor (Paint, GIMP, Photoshop, etc.)
2. Create a new image with these dimensions:
   - **Width**: 256 pixels
   - **Height**: 16 pixels
3. Fill it completely with red color (#FF0000 or any red shade)
4. Save as: `red_background.png` (PNG format)
5. Place the file in this directory: `resourcepack/assets/minecraft/textures/jquest/`

## Quick Method (Paint on Windows):
1. Open Paint
2. Click "Resize" → Set to 256 x 16 pixels
3. Use Paint Bucket tool, select red color
4. Fill the entire canvas
5. Save As → PNG → name it `red_background.png`
6. Move to: `resourcepack/assets/minecraft/textures/jquest/red_background.png`

## Testing:
1. Zip the entire `resourcepack` folder
2. Place the zip in your `.minecraft/resourcepacks/` folder
3. Enable it in Minecraft's Resource Packs menu
4. Join your server and trigger a quest notification

The red background should appear behind quest titles!
