# Custom Font for JQuest

## Where to Place Your TTF Font

1. Download a TTF font (free sources: Google Fonts, DaFont, etc.)
   - Recommended: Bold/Heavy fonts for quest headers
   - Popular choices: Montserrat Bold, Bebas Neue, Roboto Bold

2. Rename it to: `jquest-font.ttf`

3. Place it here: `resourcepack/assets/jquest/font/custom_font.ttf`

## Quick Font Recommendations

### For Quest Headers (Bold & Impactful):
- **Bebas Neue** - Clean, bold, modern
- **Montserrat ExtraBold** - Professional, readable
- **Oswald Bold** - Condensed, strong
- **Righteous** - Playful, bold

### For Descriptions (Readable):
- **Roboto** - Clean, modern
- **Open Sans** - Friendly, professional
- **Lato** - Elegant, readable

## How to Get Fonts

### Google Fonts (Free):
1. Go to: https://fonts.google.com/
2. Find a font you like
3. Click "Download family"
4. Extract the ZIP
5. Look for files ending in `.ttf`
6. Rename to `custom_font.ttf`
7. Place in `resourcepack/assets/jquest/font/`

## Font Customization

Edit `assets/jquest/font/default.json` to adjust:
- `size`: Font size (default: 11.0)
- `shift`: Move text up/down [x, y]
- `oversample`: Quality (higher = smoother but larger file size)

Example for larger, bolder text:
```json
{
  "type": "ttf",
  "file": "jquest:font/custom_font.ttf",
  "shift": [0.0, 1.0],
  "size": 13.0,
  "oversample": 2.5
}
```

## Note
This font will ONLY be used when explicitly called with `font(Key.key("jquest"))` in the code.
It won't affect Minecraft's default font or other plugins.
