# JQuest Resource Pack - Custom Textures

## Required Texture Files

Place all PNG files in this directory: `resourcepack/assets/minecraft/textures/jquest/`

### Background Textures (256x16 pixels)
Create solid color backgrounds for text:
- ✅ `red.png` - Red background (#FF0000 or similar)
- ✅ `blue.png` - Blue background (#0000FF or similar)
- ✅ `green.png` - Green background (#00FF00 or similar)
- ✅ `white.png` - White background (#FFFFFF)
- ✅ `black.png` - Black background (#000000)
- ✅ `gray.png` - Gray background (#808080 or similar)
- ✅ `pink.png` - Pink background (#FFC0CB or similar)
- ✅ `magenta.png` - Magenta background (#FF00FF)
- ✅ `yellow.png` - Yellow background (#FFFF00)
- ✅ `orange.png` - Orange background (#FFA500)
- ✅ `purple.png` - Purple background (#800080 or similar)

### Line Textures (256x3 pixels)
Create thin horizontal lines as separators:
- ✅ `white-line.png` - White line (#FFFFFF)
- ✅ `orange-line.png` - Orange line (#FFA500)
- ✅ `yellow-line.png` - Yellow line (#FFFF00)

## Quick Creation Guide (Windows Paint)

### For Background Textures (256x16):
1. Open Paint
2. Click **Resize** → Set to **256 x 16 pixels**
3. Use Paint Bucket, fill with desired color
4. **Save As PNG** with the correct filename

### For Line Textures (256x3):
1. Open Paint
2. Click **Resize** → Set to **256 x 3 pixels**
3. Use Paint Bucket, fill with desired color
4. **Save As PNG** with the correct filename

## Usage in Plugin

Once textures are added:

1. **ZIP the resource pack** (select all files in `/resourcepack/`, compress)
2. **Upload to GitHub** or file host
3. **Add to server.properties**:
   ```properties
   resource-pack=https://your-download-link.com/JQuest-ResourcePack.zip
   ```
4. **Enable in config.yml**:
   ```yaml
   use_custom_textures: true
   ```

## How It Works

The plugin uses Unicode characters mapped to these textures:
- **Quest Assigned**: Orange line + Orange background
- **Quest Completed**: Yellow line + Green background
- **Custom messages**: Use any color combination

The text appears **on top of** the colored background for a modern, styled look!
